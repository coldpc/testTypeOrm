
import {Entity,  PrimaryColumn, Column} from "typeorm";
@Entity()
export class BcRoleUser {
            
    @PrimaryColumn({
        type: 'mediumint', name: 'role_id'
    })
    roleId: number;

            
    @PrimaryColumn({
        type: 'char', name: 'user_id'
    })
    userId: string;
}