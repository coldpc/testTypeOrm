
import {Entity,  PrimaryGeneratedColumn, Column} from "typeorm";
@Entity()
export class SysRoleFunction {
            
    @PrimaryGeneratedColumn('uuid')
    id: number;

            
    @Column({
        type: 'int', name: 'role_id', comment: '登录的用户'
    })
    roleId: number;

            
    @Column({
        type: 'varchar', name: 'function_id', nullable: true
    })
    functionId: string;

            
    @Column({
        type: 'datetime', name: 'create_date'
    })
    createDate: Date;

            
    @Column({
        type: 'int', name: 'create_by'
    })
    createBy: number;

            
    @Column({
        type: 'int', name: 'last_updated_by'
    })
    lastUpdatedBy: number;

            
    @Column({
        type: 'datetime', name: 'last_updated_date'
    })
    lastUpdatedDate: Date;
}