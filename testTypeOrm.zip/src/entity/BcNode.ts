
import {Entity,  PrimaryGeneratedColumn, PrimaryColumn, Column} from "typeorm";
@Entity()
export class BcNode {
            
    @PrimaryGeneratedColumn('uuid')
    id: number;

            
    @PrimaryColumn({
        type: 'varchar', name: 'name'
    })
    name: string;

            
    @Column({
        type: 'varchar', name: 'title', nullable: true
    })
    title: string;

            
    @PrimaryColumn({
        type: 'tinyint', name: 'status', default: '0'
    })
    status: number;

            
    @Column({
        type: 'varchar', name: 'remark', nullable: true
    })
    remark: string;

            
    @Column({
        type: 'smallint', name: 'sort', nullable: true, default: '999'
    })
    sort: number;

            
    @PrimaryColumn({
        type: 'smallint', name: 'pid'
    })
    pid: number;

            
    @PrimaryColumn({
        type: 'tinyint', name: 'level'
    })
    level: number;
}