
import {Entity,  PrimaryGeneratedColumn, Column} from "typeorm";
@Entity()
export class BcArticle {
            
    @PrimaryGeneratedColumn('uuid')
    id: number;

            
    @Column({
        type: 'varchar', name: 'title'
    })
    title: string;

            
    @Column({
        type: 'varchar', name: 'keyword'
    })
    keyword: string;

            
    @Column({
        type: 'varchar', name: 'description'
    })
    description: string;

            
    @Column({
        type: 'varchar', name: 'img'
    })
    img: string;

            
    @Column({
        type: 'int', name: 'cat', default: '0'
    })
    cat: number;

            
    @Column({
        type: 'text', name: 'content'
    })
    content: string;

            
    @Column({
        type: 'int', name: 'addtime'
    })
    addtime: number;

            
    @Column({
        type: 'int', name: 'pos', default: '999999'
    })
    pos: number;

            
    @Column({
        type: 'tinyint', name: 'status', default: '1'
    })
    status: number;

            
    @Column({
        type: 'int', name: 'hits', default: '1'
    })
    hits: number;

            
    @Column({
        type: 'varchar', name: 'author', nullable: true
    })
    author: string;

            
    @Column({
        type: 'varchar', name: 'url', nullable: true
    })
    url: string;

            
    @Column({
        type: 'varchar', name: 'editor', nullable: true
    })
    editor: string;

            
    @Column({
        type: 'varchar', name: 'itemlist', nullable: true
    })
    itemlist: string;

            
    @PrimaryGeneratedColumn('uuid')
    id: string;

            
    @Column({
        type: 'varchar', name: 'title'
    })
    title: string;

            
    @Column({
        type: 'varchar', name: 'keyword'
    })
    keyword: string;

            
    @Column({
        type: 'varchar', name: 'description'
    })
    description: string;

            
    @Column({
        type: 'varchar', name: 'img'
    })
    img: string;

            
    @Column({
        type: 'int', name: 'cat', default: '0'
    })
    cat: number;

            
    @Column({
        type: 'text', name: 'content'
    })
    content: string;

            
    @Column({
        type: 'int', name: 'addtime'
    })
    addtime: number;

            
    @Column({
        type: 'int', name: 'pos', default: '999999'
    })
    pos: number;

            
    @Column({
        type: 'tinyint', name: 'status', default: '1'
    })
    status: number;

            
    @Column({
        type: 'int', name: 'hits', default: '1'
    })
    hits: number;

            
    @Column({
        type: 'varchar', name: 'author', nullable: true
    })
    author: string;

            
    @Column({
        type: 'varchar', name: 'url', nullable: true
    })
    url: string;

            
    @Column({
        type: 'varchar', name: 'editor', nullable: true
    })
    editor: string;

            
    @Column({
        type: 'varchar', name: 'itemlist', nullable: true
    })
    itemlist: string;
}