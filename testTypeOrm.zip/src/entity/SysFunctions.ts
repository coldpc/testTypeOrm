
import {Entity,  PrimaryGeneratedColumn, Column} from "typeorm";
@Entity()
export class SysFunctions {
            
    @PrimaryGeneratedColumn('uuid')
    id: number;

            
    @Column({
        type: 'varchar', name: 'code', comment: '功能编码'
    })
    code: string;

            
    @Column({
        type: 'varchar', name: 'type', comment: '功能编码page/menu', default: 'page'
    })
    type: string;

            
    @Column({
        type: 'varchar', name: 'page_url', nullable: true, comment: '如果是page,则需要url'
    })
    pageUrl: string;

            
    @Column({
        type: 'varchar', name: 'title', comment: '菜单名'
    })
    title: string;

            
    @Column({
        type: 'int', name: 'parent', nullable: true, comment: '绑定父级菜单'
    })
    parent: number;

            
    @Column({
        type: 'datetime', name: 'create_date'
    })
    createDate: Date;

            
    @Column({
        type: 'int', name: 'create_by'
    })
    createBy: number;

            
    @Column({
        type: 'int', name: 'last_updated_by'
    })
    lastUpdatedBy: number;

            
    @Column({
        type: 'datetime', name: 'last_updated_date'
    })
    lastUpdatedDate: Date;
}