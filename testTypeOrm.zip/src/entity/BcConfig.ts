
import {Entity,  PrimaryGeneratedColumn, Column} from "typeorm";
@Entity()
export class BcConfig {
            
    @PrimaryGeneratedColumn('uuid')
    id: number;

            
    @Column({
        type: 'varchar', name: 'site_name', nullable: true, default: 'site name'
    })
    siteName: string;

            
    @Column({
        type: 'varchar', name: 'kw', nullable: true
    })
    kw: string;

            
    @Column({
        type: 'varchar', name: 'description', nullable: true
    })
    description: string;

            
    @Column({
        type: 'varchar', name: 'domain', nullable: true
    })
    domain: string;

            
    @Column({
        type: 'varchar', name: 'email', nullable: true
    })
    email: string;

            
    @Column({
        type: 'varchar', name: 'tel', nullable: true
    })
    tel: string;

            
    @Column({
        type: 'varchar', name: 'qq', nullable: true
    })
    qq: string;

            
    @Column({
        type: 'varchar', name: 'company', nullable: true
    })
    company: string;

            
    @Column({
        type: 'varchar', name: 'address', nullable: true
    })
    address: string;

            
    @Column({
        type: 'varchar', name: 'icp', nullable: true
    })
    icp: string;

            
    @Column({
        type: 'tinyint', name: 'wmtype', default: '0'
    })
    wmtype: number;

            
    @Column({
        type: 'tinyint', name: 'wmpos', default: '1'
    })
    wmpos: number;

            
    @Column({
        type: 'varchar', name: 'wmtext', nullable: true
    })
    wmtext: string;

            
    @Column({
        type: 'varchar', name: 'wmtextfont', nullable: true
    })
    wmtextfont: string;

            
    @Column({
        type: 'smallint', name: 'wmtextsize', default: '14'
    })
    wmtextsize: number;

            
    @Column({
        type: 'varchar', name: 'wmtextcolor', default: '#000000'
    })
    wmtextcolor: string;

            
    @Column({
        type: 'varchar', name: 'wmphoto', nullable: true
    })
    wmphoto: string;

            
    @Column({
        type: 'smallint', name: 'wmphotoalpha', default: '80'
    })
    wmphotoalpha: number;

            
    @Column({
        type: 'int', name: 'stock', default: '100000'
    })
    stock: number;

            
    @Column({
        type: 'int', name: 'stock_balance', default: '100000'
    })
    stockBalance: number;

            
    @PrimaryGeneratedColumn('uuid')
    id: string;

            
    @Column({
        type: 'varchar', name: 'site_name', nullable: true, default: 'site name'
    })
    siteName: string;

            
    @Column({
        type: 'varchar', name: 'kw', nullable: true
    })
    kw: string;

            
    @Column({
        type: 'varchar', name: 'description', nullable: true
    })
    description: string;

            
    @Column({
        type: 'varchar', name: 'domain', nullable: true
    })
    domain: string;

            
    @Column({
        type: 'varchar', name: 'email', nullable: true
    })
    email: string;

            
    @Column({
        type: 'varchar', name: 'tel', nullable: true
    })
    tel: string;

            
    @Column({
        type: 'varchar', name: 'qq', nullable: true
    })
    qq: string;

            
    @Column({
        type: 'varchar', name: 'company', nullable: true
    })
    company: string;

            
    @Column({
        type: 'varchar', name: 'address', nullable: true
    })
    address: string;

            
    @Column({
        type: 'varchar', name: 'icp', nullable: true
    })
    icp: string;

            
    @Column({
        type: 'tinyint', name: 'wmtype', default: '0'
    })
    wmtype: number;

            
    @Column({
        type: 'tinyint', name: 'wmpos', default: '1'
    })
    wmpos: number;

            
    @Column({
        type: 'varchar', name: 'wmtext', nullable: true
    })
    wmtext: string;

            
    @Column({
        type: 'varchar', name: 'wmtextfont', nullable: true
    })
    wmtextfont: string;

            
    @Column({
        type: 'smallint', name: 'wmtextsize', default: '14'
    })
    wmtextsize: number;

            
    @Column({
        type: 'varchar', name: 'wmtextcolor', default: '#000000'
    })
    wmtextcolor: string;

            
    @Column({
        type: 'varchar', name: 'wmphoto', nullable: true
    })
    wmphoto: string;

            
    @Column({
        type: 'smallint', name: 'wmphotoalpha', default: '80'
    })
    wmphotoalpha: number;

            
    @Column({
        type: 'int', name: 'stock', default: '100000'
    })
    stock: number;

            
    @Column({
        type: 'int', name: 'stock_balance', default: '100000'
    })
    stockBalance: number;
}