
import {Entity,  PrimaryGeneratedColumn, PrimaryColumn, Column} from "typeorm";
@Entity()
export class BcRole {
            
    @PrimaryGeneratedColumn('uuid')
    id: number;

            
    @Column({
        type: 'varchar', name: 'name'
    })
    name: string;

            
    @PrimaryColumn({
        type: 'smallint', name: 'pid', default: '0'
    })
    pid: number;

            
    @PrimaryColumn({
        type: 'tinyint', name: 'status'
    })
    status: number;

            
    @Column({
        type: 'varchar', name: 'remark', nullable: true
    })
    remark: string;
}