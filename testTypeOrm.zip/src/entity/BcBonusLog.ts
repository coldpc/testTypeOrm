
import {Entity,  PrimaryGeneratedColumn, Column} from "typeorm";
@Entity()
export class BcBonusLog {
            
    @PrimaryGeneratedColumn('uuid')
    id: number;

            
    @Column({
        type: 'decimal', name: 'price', comment: '提现金额', default: '0.00'
    })
    price: number;

            
    @Column({
        type: 'decimal', name: 'bonus_before', comment: '体现之前的奖金剩余', default: '0.00'
    })
    bonusBefore: number;

            
    @Column({
        type: 'decimal', name: 'bonus_after', comment: '提现之后奖金剩余', default: '0.00'
    })
    bonusAfter: number;

            
    @Column({
        type: 'decimal', name: 'aim_before', comment: '提现手续费', default: '0.00'
    })
    aimBefore: number;

            
    @Column({
        type: 'decimal', name: 'aim_after', comment: '提现实际到账', default: '0.00'
    })
    aimAfter: number;

            
    @Column({
        type: 'float', name: 'trans_rate', comment: '费率', default: '1'
    })
    transRate: number;

            
    @Column({
        type: 'int', name: 'trans_time', comment: '提现申请时间', default: '0'
    })
    transTime: number;

            
    @Column({
        type: 'varchar', name: 'trans_type', nullable: true, comment: '转换类型 zhitui/jiandian/peng'
    })
    transType: string;

            
    @Column({
        type: 'int', name: 'uid', comment: '对碰用户', default: '0'
    })
    uid: number;

            
    @Column({
        type: 'int', name: 'uid2', default: '0'
    })
    uid2: number;

            
    @Column({
        type: 'decimal', name: 'bonus_coin', comment: '奖金币', default: '0.00'
    })
    bonusCoin: number;

            
    @Column({
        type: 'decimal', name: 'stock_coin', comment: '股票', default: '0.00'
    })
    stockCoin: number;

            
    @Column({
        type: 'decimal', name: 'consume_coin', comment: '消费币', default: '0.00'
    })
    consumeCoin: number;

            
    @Column({
        type: 'varchar', name: 'user_remarks', nullable: true
    })
    userRemarks: string;

            
    @Column({
        type: 'varchar', name: 'admin_remarks', nullable: true
    })
    adminRemarks: string;

            
    @Column({
        type: 'int', name: 'confirm_time', default: '0'
    })
    confirmTime: number;

            
    @Column({
        type: 'tinyint', name: 'status', default: '0'
    })
    status: number;

            
    @Column({
        type: 'int', name: 'edition', default: '0'
    })
    edition: number;

            
    @PrimaryGeneratedColumn('uuid')
    id: string;

            
    @Column({
        type: 'decimal', name: 'price', comment: '提现金额', default: '0'
    })
    price: number;

            
    @Column({
        type: 'decimal', name: 'bonus_before', comment: '体现之前的奖金剩余', default: '0'
    })
    bonusBefore: number;

            
    @Column({
        type: 'decimal', name: 'bonus_after', comment: '提现之后奖金剩余', default: '0'
    })
    bonusAfter: number;

            
    @Column({
        type: 'decimal', name: 'aim_before', comment: '提现手续费', default: '0'
    })
    aimBefore: number;

            
    @Column({
        type: 'decimal', name: 'aim_after', comment: '提现实际到账', default: '0'
    })
    aimAfter: number;

            
    @Column({
        type: 'float', name: 'trans_rate', comment: '费率', default: '1'
    })
    transRate: number;

            
    @Column({
        type: 'int', name: 'trans_time', comment: '提现申请时间', default: '0'
    })
    transTime: number;

            
    @Column({
        type: 'varchar', name: 'trans_type', nullable: true, comment: '转换类型 zhitui/jiandian/peng'
    })
    transType: string;

            
    @Column({
        type: 'int', name: 'uid', comment: '对碰用户', default: '0'
    })
    uid: number;

            
    @Column({
        type: 'int', name: 'uid2', default: '0'
    })
    uid2: number;

            
    @Column({
        type: 'decimal', name: 'bonus_coin', comment: '奖金币', default: '0'
    })
    bonusCoin: number;

            
    @Column({
        type: 'decimal', name: 'stock_coin', comment: '股票', default: '0'
    })
    stockCoin: number;

            
    @Column({
        type: 'decimal', name: 'consume_coin', comment: '消费币', default: '0'
    })
    consumeCoin: number;

            
    @Column({
        type: 'varchar', name: 'user_remarks', nullable: true
    })
    userRemarks: string;

            
    @Column({
        type: 'varchar', name: 'admin_remarks', nullable: true
    })
    adminRemarks: string;

            
    @Column({
        type: 'int', name: 'confirm_time', default: '0'
    })
    confirmTime: number;

            
    @Column({
        type: 'tinyint', name: 'status', default: '0'
    })
    status: number;

            
    @Column({
        type: 'int', name: 'edition', default: '0'
    })
    edition: number;
}