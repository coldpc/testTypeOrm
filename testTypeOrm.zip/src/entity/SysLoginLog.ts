
import {Entity,  PrimaryGeneratedColumn, Column} from "typeorm";
@Entity()
export class SysLoginLog {
            
    @PrimaryGeneratedColumn('uuid')
    id: number;

            
    @Column({
        type: 'int', name: 'user_id', comment: '登录的用户'
    })
    userId: number;

            
    @Column({
        type: 'varchar', name: 'login_ip', nullable: true, comment: '登录ip'
    })
    loginIp: string;

            
    @Column({
        type: 'datetime', name: 'login_date', comment: '登录日期'
    })
    loginDate: Date;

            
    @Column({
        type: 'datetime', name: 'create_date'
    })
    createDate: Date;

            
    @Column({
        type: 'int', name: 'create_by'
    })
    createBy: number;

            
    @Column({
        type: 'int', name: 'last_updated_by'
    })
    lastUpdatedBy: number;

            
    @Column({
        type: 'datetime', name: 'last_updated_date'
    })
    lastUpdatedDate: Date;
}