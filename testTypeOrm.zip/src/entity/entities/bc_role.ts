import {Index,Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable} from "typeorm";


@Entity("bc_role")
@Index("pid",["pid",])
@Index("status",["status",])
export class bc_role {

    @Column("smallint",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("varchar",{ 
        nullable:false,
        length:20,
        name:"name"
        })
    name:string;
        

    @Column("smallint",{ 
        nullable:true,
        default:"0",
        name:"pid"
        })
    pid:number;
        

    @Column("tinyint",{ 
        nullable:true,
        name:"status"
        })
    status:number;
        

    @Column("varchar",{ 
        nullable:true,
        length:255,
        name:"remark"
        })
    remark:string;
        
}
