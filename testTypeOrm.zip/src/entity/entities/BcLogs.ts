import {Index,Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable} from "typeorm";


@Entity("BcLogs")
export class bc_logs {

    @Column("int",{ 
        generated:true,
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"uid"
        })
    uid:number;
        

    @Column("decimal",{ 
        nullable:false,
        precision:9,
        scale:2,
        name:"price"
        })
    price:number;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"cat"
        })
    cat:number;
        

    @Column("varchar",{ 
        nullable:true,
        length:128,
        name:"remarks"
        })
    remarks:string;
        

    @Column("int",{ 
        nullable:false,
        name:"addtime"
        })
    addtime:number;
        
}
