import {Index,Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable} from "typeorm";


@Entity("bc_levels")
export class bc_levels {

    @Column("int",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"title"
        })
    title:string;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"price"
        })
    price:number;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"bonus_daily"
        })
    bonus_daily:number;
        

    @Column("varchar",{ 
        nullable:true,
        length:128,
        name:"remarks"
        })
    remarks:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:8,
        name:"color"
        })
    color:string;
        
}
