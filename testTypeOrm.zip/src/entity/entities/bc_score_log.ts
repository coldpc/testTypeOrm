import {Index,Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable} from "typeorm";


@Entity("bc_score_log")
export class bc_score_log {

    @Column("int",{ 
        generated:true,
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("int",{ 
        nullable:true,
        name:"uid"
        })
    uid:number;
        

    @Column("varchar",{ 
        nullable:true,
        length:256,
        name:"remark"
        })
    remark:string;
        

    @Column("int",{ 
        nullable:true,
        name:"confirm_time"
        })
    confirm_time:number;
        

    @Column("varchar",{ 
        nullable:true,
        length:8,
        name:"scores"
        })
    scores:string;
        
}
