import {Index,Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable} from "typeorm";


@Entity("BcSlide")
export class bc_slide {

    @Column("int",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("varchar",{ 
        nullable:true,
        length:128,
        name:"title"
        })
    title:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"img"
        })
    img:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:256,
        default:"#",
        name:"url"
        })
    url:string;
        

    @Column("tinyint",{ 
        nullable:false,
        length:1,
        default:"9",
        name:"pos"
        })
    pos:boolean;
        

    @Column("tinyint",{ 
        nullable:false,
        length:1,
        default:"0",
        name:"type"
        })
    type:boolean;
        

    @Column("varchar",{ 
        nullable:false,
        length:7,
        default:"#fff",
        name:"color"
        })
    color:string;
        
}
