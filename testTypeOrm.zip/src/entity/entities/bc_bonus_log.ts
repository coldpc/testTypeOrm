import {Index,Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable} from "typeorm";


@Entity("bc_bonus_log")
export class bc_bonus_log {

    @Column("int",{ 
        generated:true,
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"price"
        })
    price:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"bonus_before"
        })
    bonus_before:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"bonus_after"
        })
    bonus_after:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"aim_before"
        })
    aim_before:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"aim_after"
        })
    aim_after:number;
        

    @Column("float",{ 
        nullable:false,
        default:"1",
        name:"trans_rate"
        })
    trans_rate:number;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"trans_time"
        })
    trans_time:number;
        

    @Column("varchar",{ 
        nullable:true,
        length:16,
        name:"trans_type"
        })
    trans_type:string;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"uid"
        })
    uid:number;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"uid2"
        })
    uid2:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"bonus_coin"
        })
    bonus_coin:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"stock_coin"
        })
    stock_coin:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"consume_coin"
        })
    consume_coin:number;
        

    @Column("varchar",{ 
        nullable:true,
        length:128,
        name:"user_remarks"
        })
    user_remarks:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:128,
        name:"admin_remarks"
        })
    admin_remarks:string;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"confirm_time"
        })
    confirm_time:number;
        

    @Column("tinyint",{ 
        nullable:false,
        length:1,
        default:"0",
        name:"status"
        })
    status:boolean;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"edition"
        })
    edition:number;
        
}
