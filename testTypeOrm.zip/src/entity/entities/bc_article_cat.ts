import {Index,Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable} from "typeorm";


@Entity("bc_article_cat")
export class bc_article_cat {

    @Column("int",{ 
        generated:true,
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("varchar",{ 
        nullable:false,
        length:32,
        name:"title"
        })
    title:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"img"
        })
    img:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:256,
        name:"keyword"
        })
    keyword:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:256,
        name:"description"
        })
    description:string;
        

    @Column("int",{ 
        nullable:false,
        default:"999999",
        name:"pos"
        })
    pos:number;
        
}
