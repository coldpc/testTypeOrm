import {Index,Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable} from "typeorm";


@Entity("bc_role_user")
@Index("group_id",["role_id",])
@Index("user_id",["user_id",])
export class bc_role_user {

    @Column("mediumint",{ 
        nullable:true,
        name:"role_id"
        })
    role_id:number;
        

    @Column("char",{ 
        nullable:true,
        name:"user_id"
        })
    user_id:string;
        
}
