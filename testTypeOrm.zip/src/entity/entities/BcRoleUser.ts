import {Index,Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable} from "typeorm";


@Entity("BcRoleUser")
@Index("group_id",["role_id",])
@Index("user_id",["user_id",])
export class bc_role_user {

    @Column("mediumint",{ 
        nullable:true,
        name:"role_id"
        })
    roleId:number;
        

    @Column("char",{ 
        nullable:true,
        name:"user_id"
        })
    userId:string;
        
}
