import {Index,Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable} from "typeorm";


@Entity("BcNode")
@Index("level",["level",])
@Index("pid",["pid",])
@Index("status",["status",])
@Index("name",["name",])
export class bc_node {

    @Column("smallint",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("varchar",{ 
        nullable:false,
        length:20,
        name:"name"
        })
    name:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:50,
        name:"title"
        })
    title:string;
        

    @Column("tinyint",{ 
        nullable:true,
        length:1,
        default:"0",
        name:"status"
        })
    status:boolean;
        

    @Column("varchar",{ 
        nullable:true,
        length:255,
        name:"remark"
        })
    remark:string;
        

    @Column("smallint",{ 
        nullable:true,
        default:"999",
        name:"sort"
        })
    sort:number;
        

    @Column("smallint",{ 
        nullable:false,
        name:"pid"
        })
    pid:number;
        

    @Column("tinyint",{ 
        nullable:false,
        name:"level"
        })
    level:number;
        
}
