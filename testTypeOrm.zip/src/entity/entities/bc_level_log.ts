import {Index,Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable} from "typeorm";


@Entity("bc_level_log")
export class bc_level_log {

    @Column("int",{ 
        generated:true,
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"price"
        })
    price:number;
        

    @Column("int",{ 
        nullable:false,
        name:"uid"
        })
    uid:number;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"service_id"
        })
    service_id:number;
        

    @Column("int",{ 
        nullable:false,
        name:"lvl_now"
        })
    lvl_now:number;
        

    @Column("int",{ 
        nullable:false,
        name:"lvl_aim"
        })
    lvl_aim:number;
        

    @Column("tinyint",{ 
        nullable:false,
        length:1,
        default:"0",
        name:"status"
        })
    status:boolean;
        

    @Column("int",{ 
        nullable:false,
        name:"add_time"
        })
    add_time:number;
        

    @Column("int",{ 
        nullable:false,
        name:"confirm_time"
        })
    confirm_time:number;
        
}
