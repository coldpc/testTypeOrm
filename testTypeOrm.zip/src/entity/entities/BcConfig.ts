import {Index,Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable} from "typeorm";


@Entity("BcConfig")
export class bc_config {

    @Column("int",{ 
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("varchar",{ 
        nullable:true,
        length:64,
        default:"site name",
        name:"site_name"
        })
    siteName:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:128,
        name:"kw"
        })
    kw:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:256,
        name:"description"
        })
    description:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"domain"
        })
    domain:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"email"
        })
    email:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"tel"
        })
    tel:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:128,
        name:"qq"
        })
    qq:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"company"
        })
    company:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:128,
        name:"address"
        })
    address:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"icp"
        })
    icp:string;
        

    @Column("tinyint",{ 
        nullable:false,
        length:1,
        default:"0",
        name:"wmtype"
        })
    wmtype:boolean;
        

    @Column("tinyint",{ 
        nullable:false,
        length:1,
        default:"1",
        name:"wmpos"
        })
    wmpos:boolean;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"wmtext"
        })
    wmtext:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"wmtextfont"
        })
    wmtextfont:string;
        

    @Column("smallint",{ 
        nullable:false,
        default:"14",
        name:"wmtextsize"
        })
    wmtextsize:number;
        

    @Column("varchar",{ 
        nullable:false,
        length:9,
        default:"#000000",
        name:"wmtextcolor"
        })
    wmtextcolor:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"wmphoto"
        })
    wmphoto:string;
        

    @Column("smallint",{ 
        nullable:false,
        default:"80",
        name:"wmphotoalpha"
        })
    wmphotoalpha:number;
        

    @Column("int",{ 
        nullable:false,
        default:"100000",
        name:"stock"
        })
    stock:number;
        

    @Column("int",{ 
        nullable:false,
        default:"100000",
        name:"stock_balance"
        })
    stockBalance:number;
        
}
