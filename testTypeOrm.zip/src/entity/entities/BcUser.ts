import {Index,Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable} from "typeorm";


@Entity("BcUser")
export class bc_user {

    @Column("int",{ 
        generated:true,
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"realname"
        })
    realname:string;
        

    @Column("tinyint",{ 
        nullable:false,
        length:1,
        default:"0",
        name:"gender"
        })
    gender:boolean;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"username"
        })
    username:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"password"
        })
    password:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:18,
        name:"idcard"
        })
    idcard:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:11,
        name:"tel"
        })
    tel:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"qq"
        })
    qq:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"email"
        })
    email:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:50,
        name:"address"
        })
    address:string;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"balance"
        })
    balance:number;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"stock"
        })
    stock:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"stock_60"
        })
    stock_60:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"stock_25"
        })
    stock_25:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"stock_15"
        })
    stock_15:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"score"
        })
    score:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"bonus_coin"
        })
    bonusCoin:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"stock_coin"
        })
    stockCoin:number;
        

    @Column("decimal",{ 
        nullable:false,
        default:"0.00",
        precision:9,
        scale:2,
        name:"consume_coin"
        })
    consumeCoin:number;
        

    @Column("varchar",{ 
        nullable:true,
        length:64,
        name:"bank_name"
        })
    bankName:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"bank_realname"
        })
    bankRealname:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"bank_accounts"
        })
    bankAccounts:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:16,
        default:"零售商",
        name:"marketrole"
        })
    marketrole:string;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"user_level"
        })
    userLevel:number;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"rec_id"
        })
    recId:number;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"parent_id"
        })
    parentId:number;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"service_id"
        })
    serviceId:number;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"log_time"
        })
    logTime:number;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"log_ip"
        })
    logIp:string;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"reg_time"
        })
    regTime:number;
        

    @Column("tinyint",{ 
        nullable:false,
        length:1,
        default:"0",
        name:"is_register"
        })
    isRegister:boolean;
        

    @Column("tinyint",{ 
        nullable:false,
        length:1,
        default:"0",
        name:"is_service"
        })
    isService:boolean;
        

    @Column("tinyint",{ 
        nullable:false,
        length:1,
        default:"0",
        name:"status"
        })
    status:boolean;
        

    @Column("int",{ 
        nullable:false,
        default:"999999",
        name:"pos"
        })
    pos:number;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"edition"
        })
    edition:number;
        
}
