import {Index,Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable} from "typeorm";


@Entity("BcAccess")
@Index("groupId",["role_id",])
@Index("nodeId",["node_id",])
export class bc_access {

    @Column("varchar",{ 
        nullable:false,
        length:225,
        primary:true,
        name:"id"
        })
    id:string;
        

    @Column("smallint",{ 
        nullable:false,
        name:"role_id"
        })
    roleId:number;
        

    @Column("smallint",{ 
        nullable:false,
        name:"node_id"
        })
    nodeId:number;
        

    @Column("tinyint",{ 
        nullable:false,
        length:1,
        name:"level"
        })
    level:boolean;
        

    @Column("varchar",{ 
        nullable:true,
        length:50,
        name:"module"
        })
    module:string;
        
}
