import {Index,Entity, PrimaryColumn, Column, OneToOne, OneToMany, ManyToOne, ManyToMany, JoinColumn, JoinTable} from "typeorm";


@Entity("bc_article")
export class bc_article {

    @Column("int",{ 
        generated:true,
        nullable:false,
        primary:true,
        name:"id"
        })
    id:number;
        

    @Column("varchar",{ 
        nullable:false,
        length:128,
        name:"title"
        })
    title:string;
        

    @Column("varchar",{ 
        nullable:false,
        length:128,
        name:"keyword"
        })
    keyword:string;
        

    @Column("varchar",{ 
        nullable:false,
        length:256,
        name:"description"
        })
    description:string;
        

    @Column("varchar",{ 
        nullable:false,
        length:32,
        name:"img"
        })
    img:string;
        

    @Column("int",{ 
        nullable:false,
        default:"0",
        name:"cat"
        })
    cat:number;
        

    @Column("text",{ 
        nullable:false,
        name:"content"
        })
    content:string;
        

    @Column("int",{ 
        nullable:false,
        name:"addtime"
        })
    addtime:number;
        

    @Column("int",{ 
        nullable:false,
        default:"999999",
        name:"pos"
        })
    pos:number;
        

    @Column("tinyint",{ 
        nullable:false,
        default:"1",
        name:"status"
        })
    status:number;
        

    @Column("int",{ 
        nullable:false,
        default:"1",
        name:"hits"
        })
    hits:number;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"author"
        })
    author:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:64,
        name:"url"
        })
    url:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:32,
        name:"editor"
        })
    editor:string;
        

    @Column("varchar",{ 
        nullable:true,
        length:128,
        name:"itemlist"
        })
    itemlist:string;
        
}
