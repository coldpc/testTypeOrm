
import {Entity,  PrimaryGeneratedColumn, Column} from "typeorm";
@Entity()
export class BcScoreLog {
            
    @PrimaryGeneratedColumn('uuid')
    id: number;

            
    @Column({
        type: 'int', name: 'uid', nullable: true
    })
    uid: number;

            
    @Column({
        type: 'varchar', name: 'remark', nullable: true
    })
    remark: string;

            
    @Column({
        type: 'int', name: 'confirm_time', nullable: true
    })
    confirmTime: number;

            
    @Column({
        type: 'varchar', name: 'scores', nullable: true
    })
    scores: string;
}