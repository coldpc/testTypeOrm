
import {Entity,  PrimaryGeneratedColumn, Column} from "typeorm";
@Entity()
export class BcLogs {
            
    @PrimaryGeneratedColumn('uuid')
    id: number;

            
    @Column({
        type: 'int', name: 'uid', default: '0'
    })
    uid: number;

            
    @Column({
        type: 'decimal', name: 'price'
    })
    price: number;

            
    @Column({
        type: 'int', name: 'cat', default: '0'
    })
    cat: number;

            
    @Column({
        type: 'varchar', name: 'remarks', nullable: true
    })
    remarks: string;

            
    @Column({
        type: 'int', name: 'addtime'
    })
    addtime: number;

            
    @PrimaryGeneratedColumn('uuid')
    id: string;

            
    @Column({
        type: 'int', name: 'uid', default: '0'
    })
    uid: number;

            
    @Column({
        type: 'decimal', name: 'price'
    })
    price: number;

            
    @Column({
        type: 'int', name: 'cat', default: '0'
    })
    cat: number;

            
    @Column({
        type: 'varchar', name: 'remarks', nullable: true
    })
    remarks: string;

            
    @Column({
        type: 'int', name: 'addtime'
    })
    addtime: number;
}