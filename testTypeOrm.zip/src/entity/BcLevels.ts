
import {Entity,  PrimaryGeneratedColumn, Column} from "typeorm";
@Entity()
export class BcLevels {
            
    @PrimaryGeneratedColumn('uuid')
    id: number;

            
    @Column({
        type: 'varchar', name: 'title', nullable: true
    })
    title: string;

            
    @Column({
        type: 'int', name: 'price', default: '0'
    })
    price: number;

            
    @Column({
        type: 'int', name: 'bonus_daily', default: '0'
    })
    bonusDaily: number;

            
    @Column({
        type: 'varchar', name: 'remarks', nullable: true
    })
    remarks: string;

            
    @Column({
        type: 'varchar', name: 'color', nullable: true
    })
    color: string;

            
    @PrimaryGeneratedColumn('uuid')
    id: string;

            
    @Column({
        type: 'varchar', name: 'title', nullable: true
    })
    title: string;

            
    @Column({
        type: 'int', name: 'price', default: '0'
    })
    price: number;

            
    @Column({
        type: 'int', name: 'bonus_daily', default: '0'
    })
    bonusDaily: number;

            
    @Column({
        type: 'varchar', name: 'remarks', nullable: true
    })
    remarks: string;

            
    @Column({
        type: 'varchar', name: 'color', nullable: true
    })
    color: string;
}