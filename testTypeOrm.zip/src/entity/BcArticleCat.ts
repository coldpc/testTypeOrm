
import {Entity,  PrimaryGeneratedColumn, Column} from "typeorm";
@Entity()
export class BcArticleCat {
            
    @PrimaryGeneratedColumn('uuid')
    id: number;

            
    @Column({
        type: 'varchar', name: 'title'
    })
    title: string;

            
    @Column({
        type: 'varchar', name: 'img', nullable: true
    })
    img: string;

            
    @Column({
        type: 'varchar', name: 'keyword', nullable: true
    })
    keyword: string;

            
    @Column({
        type: 'varchar', name: 'description', nullable: true
    })
    description: string;

            
    @Column({
        type: 'int', name: 'pos', default: '999999'
    })
    pos: number;

            
    @PrimaryGeneratedColumn('uuid')
    id: string;

            
    @Column({
        type: 'varchar', name: 'title'
    })
    title: string;

            
    @Column({
        type: 'varchar', name: 'img', nullable: true
    })
    img: string;

            
    @Column({
        type: 'varchar', name: 'keyword', nullable: true
    })
    keyword: string;

            
    @Column({
        type: 'varchar', name: 'description', nullable: true
    })
    description: string;

            
    @Column({
        type: 'int', name: 'pos', default: '999999'
    })
    pos: number;
}