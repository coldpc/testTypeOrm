
import {Entity,  PrimaryGeneratedColumn, Column} from "typeorm";
@Entity()
export class BcLevelLog {
            
    @PrimaryGeneratedColumn('uuid')
    id: number;

            
    @Column({
        type: 'decimal', name: 'price', default: '0.00'
    })
    price: number;

            
    @Column({
        type: 'int', name: 'uid'
    })
    uid: number;

            
    @Column({
        type: 'int', name: 'service_id', default: '0'
    })
    serviceId: number;

            
    @Column({
        type: 'int', name: 'lvl_now'
    })
    lvlNow: number;

            
    @Column({
        type: 'int', name: 'lvl_aim'
    })
    lvlAim: number;

            
    @Column({
        type: 'tinyint', name: 'status', default: '0'
    })
    status: number;

            
    @Column({
        type: 'int', name: 'add_time'
    })
    addTime: number;

            
    @Column({
        type: 'int', name: 'confirm_time'
    })
    confirmTime: number;

            
    @PrimaryGeneratedColumn('uuid')
    id: string;

            
    @Column({
        type: 'decimal', name: 'price', default: '0'
    })
    price: number;

            
    @Column({
        type: 'int', name: 'uid'
    })
    uid: number;

            
    @Column({
        type: 'int', name: 'service_id', default: '0'
    })
    serviceId: number;

            
    @Column({
        type: 'int', name: 'lvl_now'
    })
    lvlNow: number;

            
    @Column({
        type: 'int', name: 'lvl_aim'
    })
    lvlAim: number;

            
    @Column({
        type: 'tinyint', name: 'status', default: '0'
    })
    status: number;

            
    @Column({
        type: 'int', name: 'add_time'
    })
    addTime: number;

            
    @Column({
        type: 'int', name: 'confirm_time'
    })
    confirmTime: number;
}