
import {Entity,  PrimaryGeneratedColumn, Column} from "typeorm";
@Entity()
export class BcUser {
            
    @PrimaryGeneratedColumn('uuid')
    id: number;

            
    @Column({
        type: 'varchar', name: 'realname', nullable: true
    })
    realname: string;

            
    @Column({
        type: 'tinyint', name: 'gender', default: '0'
    })
    gender: number;

            
    @Column({
        type: 'varchar', name: 'username', nullable: true
    })
    username: string;

            
    @Column({
        type: 'varchar', name: 'password', nullable: true
    })
    password: string;

            
    @Column({
        type: 'varchar', name: 'idcard', nullable: true
    })
    idcard: string;

            
    @Column({
        type: 'varchar', name: 'tel', nullable: true
    })
    tel: string;

            
    @Column({
        type: 'varchar', name: 'qq', nullable: true
    })
    qq: string;

            
    @Column({
        type: 'varchar', name: 'email', nullable: true
    })
    email: string;

            
    @Column({
        type: 'varchar', name: 'address', nullable: true
    })
    address: string;

            
    @Column({
        type: 'decimal', name: 'balance', default: '0.00'
    })
    balance: number;

            
    @Column({
        type: 'int', name: 'stock', default: '0'
    })
    stock: number;

            
    @Column({
        type: 'decimal', name: 'stock_60', default: '0.00'
    })
    stock_60: number;

            
    @Column({
        type: 'decimal', name: 'stock_25', default: '0.00'
    })
    stock_25: number;

            
    @Column({
        type: 'decimal', name: 'stock_15', default: '0.00'
    })
    stock_15: number;

            
    @Column({
        type: 'decimal', name: 'score', default: '0.00'
    })
    score: number;

            
    @Column({
        type: 'decimal', name: 'bonus_coin', default: '0.00'
    })
    bonusCoin: number;

            
    @Column({
        type: 'decimal', name: 'stock_coin', default: '0.00'
    })
    stockCoin: number;

            
    @Column({
        type: 'decimal', name: 'consume_coin', default: '0.00'
    })
    consumeCoin: number;

            
    @Column({
        type: 'varchar', name: 'bank_name', nullable: true
    })
    bankName: string;

            
    @Column({
        type: 'varchar', name: 'bank_realname', nullable: true
    })
    bankRealname: string;

            
    @Column({
        type: 'varchar', name: 'bank_accounts', nullable: true
    })
    bankAccounts: string;

            
    @Column({
        type: 'varchar', name: 'marketrole', nullable: true, default: '零售商'
    })
    marketrole: string;

            
    @Column({
        type: 'int', name: 'user_level', default: '0'
    })
    userLevel: number;

            
    @Column({
        type: 'int', name: 'rec_id', default: '0'
    })
    recId: number;

            
    @Column({
        type: 'int', name: 'parent_id', default: '0'
    })
    parentId: number;

            
    @Column({
        type: 'int', name: 'service_id', default: '0'
    })
    serviceId: number;

            
    @Column({
        type: 'int', name: 'log_time', default: '0'
    })
    logTime: number;

            
    @Column({
        type: 'varchar', name: 'log_ip', nullable: true
    })
    logIp: string;

            
    @Column({
        type: 'int', name: 'reg_time', default: '0'
    })
    regTime: number;

            
    @Column({
        type: 'tinyint', name: 'is_register', default: '0'
    })
    isRegister: number;

            
    @Column({
        type: 'tinyint', name: 'is_service', default: '0'
    })
    isService: number;

            
    @Column({
        type: 'tinyint', name: 'status', default: '0'
    })
    status: number;

            
    @Column({
        type: 'int', name: 'pos', default: '999999'
    })
    pos: number;

            
    @Column({
        type: 'int', name: 'edition', default: '0'
    })
    edition: number;
}