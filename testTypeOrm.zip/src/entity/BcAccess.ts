
import {Entity,  PrimaryGeneratedColumn, PrimaryColumn, Column} from "typeorm";
@Entity()
export class BcAccess {
            
    @PrimaryGeneratedColumn('uuid')
    id: string;

            
    @PrimaryColumn({
        type: 'smallint', name: 'role_id'
    })
    roleId: number;

            
    @PrimaryColumn({
        type: 'smallint', name: 'node_id'
    })
    nodeId: number;

            
    @Column({
        type: 'tinyint', name: 'level'
    })
    level: number;

            
    @Column({
        type: 'varchar', name: 'module', nullable: true
    })
    module: string;

            
    @PrimaryGeneratedColumn('uuid')
    roleId: number;

            
    @PrimaryGeneratedColumn('uuid')
    nodeId: number;

            
    @Column({
        type: 'tinyint', name: 'level'
    })
    level: number;

            
    @Column({
        type: 'varchar', name: 'module', nullable: true
    })
    module: string;
}