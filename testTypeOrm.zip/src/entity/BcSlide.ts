
import {Entity,  PrimaryGeneratedColumn, Column} from "typeorm";
@Entity()
export class BcSlide {
            
    @PrimaryGeneratedColumn('uuid')
    id: number;

            
    @Column({
        type: 'varchar', name: 'title', nullable: true
    })
    title: string;

            
    @Column({
        type: 'varchar', name: 'img', nullable: true
    })
    img: string;

            
    @Column({
        type: 'varchar', name: 'url', nullable: true, default: '#'
    })
    url: string;

            
    @Column({
        type: 'tinyint', name: 'pos', default: '9'
    })
    pos: number;

            
    @Column({
        type: 'tinyint', name: 'type', default: '0'
    })
    type: number;

            
    @Column({
        type: 'varchar', name: 'color', default: '#fff'
    })
    color: string;
}