# Awesome Project Build with TypeORM
        
Steps to run this project:

1. Run `npm i` command
2. Setup database settings inside `ormconfig.json` file
3. Run `npm start` command




/******************数据类型**********************/
int, tinyint, smallint, mediumint, bigint, decimal, float, double, real, 
datetime, time, timestamp, character, varchar, char, tinyblob, tinytext, 
mediumblob, mediumtext, blob, text, longblob, longtext, date, year, enum, json


/******************自动生成模型********************/
npm i -g typeorm-model-generator 

typeorm-model-generator -h rm-uf62110sw47boc9tg2o.mysql.rds.aliyuncs.com -d hao_ke_db -u pccold -x WHQkey0825 -e mysql -o ./src/testEntity


 "host": "rm-uf62110sw47boc9tg2o.mysql.rds.aliyuncs.com",
    "port": 3306,
    "username": "pccold",
    "password": "WHQkey0825",
    "database": "haoke",